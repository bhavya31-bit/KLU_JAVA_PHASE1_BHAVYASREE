import java.util.*;
class Main{
public static void main(String[] args){
    String a = "Bhavya";
    System.out.print(a);
}
}