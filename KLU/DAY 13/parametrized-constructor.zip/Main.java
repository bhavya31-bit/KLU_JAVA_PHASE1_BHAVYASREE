class Student {
    int roll;
    String name;

    Student(int r, String n) {
        roll = r;
        name = n;
    }

    void display() {
        System.out.println(roll + " " + name);
    }
}

public class Main {
    public static void main(String[] args) {
        Student s1 = new Student(12, "ABC");
        Student s2 = new Student(13, "xyz");

        s1.display();
        s2.display();
    }
}