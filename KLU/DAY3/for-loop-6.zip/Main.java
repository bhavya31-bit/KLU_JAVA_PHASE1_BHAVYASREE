import java.util.*;
class Main {
    static int i;
    public static void main(String args[]) {
        for(;;)
        System.out.println(i + " ");
    }
}